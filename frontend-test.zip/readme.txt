1. Convert design ke dalam layout HTML dan style CSS .
2. Diperkenankan menggunakankan CSS prosessor, seperti SASS/SCSS.
3. Diharapkan tidak menggunakan CSS framework, seperti Bootstrap.
4. Image di dalam card tidak diperkenankan diresize pakai Photoshop atau photo editor lainnya,
   Resize image hanya menggunakan CSS, namun perlu diperhatikan juga rationya
5. Diharapkan membuat code Javascript dari scratch.
6. Diperkenankan menggunakan task runner, seperti NPM, Grunt, Gulp, dll.
7. Wiring data dari file JSON yang telah diberikan dan tidak ada data hardcoded dalam layout HTML.